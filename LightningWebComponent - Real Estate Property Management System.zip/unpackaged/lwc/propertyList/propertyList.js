import { LightningElement, track, wire } from 'lwc';
import getProperties   from '@salesforce/apex/PropertyController.getProperties';
import getPropertyCount from '@salesforce/apex/PropertyController.getPropertyCount';

export default class PropertyList extends LightningElement {

    // ── FILTER STATE (Step 9) ─────────────────────────────────────────
    // These hold what the user has typed/selected in the filter inputs.
    minRent          = null;
    maxRent          = null;
    status           = '';
    furnishingStatus = '';

    // ── PAGINATION STATE (Step 10) ────────────────────────────────────
    currentPage  = 1;
    pageSize     = 25;
    totalRecords = 0;

    // ── DATA ──────────────────────────────────────────────────────────
    @track properties = [];  // @track = LWC watches this array for changes
    isLoading = false;
    error     = null;

    // Computed: total pages = ceil(totalRecords / 25)
    get totalPages() {
        return Math.ceil(this.totalRecords / this.pageSize) || 1;
    }

    // Disable Previous button on first page
    get isPreviousDisabled() { return this.currentPage <= 1; }

    // Disable Next button on last page
    get isNextDisabled() { return this.currentPage >= this.totalPages; }

    // ── ON LOAD ───────────────────────────────────────────────────────
    connectedCallback() {
        this.fetchData();
    }

    // ── FETCH DATA FROM APEX (Steps 8, 10) ───────────────────────────
    fetchData() {
        this.isLoading = true;

        // Build params object to pass to both Apex methods
        const params = {
            pageSize        : this.pageSize,
            pageNumber      : this.currentPage,
            minRent         : this.minRent,
            maxRent         : this.maxRent,
            status          : this.status,
            furnishingStatus: this.furnishingStatus
        };

        // Call getPropertyCount first (for pagination)
        getPropertyCount({
            minRent         : this.minRent,
            maxRent         : this.maxRent,
            status          : this.status,
            furnishingStatus: this.furnishingStatus
        })
        .then(count => {
            this.totalRecords = count;
            // Then call getProperties (for the actual records)
            return getProperties(params);
        })
        .then(data => {
            this.properties = data;
            this.error      = null;
        })
        .catch(err => {
            this.error      = err.body?.message || 'Error loading properties';
            this.properties = [];
        })
        .finally(() => {
            this.isLoading = false;
        });
    }

    // ── FILTER HANDLERS (Step 9) ──────────────────────────────────────
    // Each handler reads the input value and resets to page 1
    handleStatusChange(event) {
        this.status      = event.target.value;
        this.currentPage = 1;
        this.fetchData();
    }

    handleFurnishingChange(event) {
        this.furnishingStatus = event.target.value;
        this.currentPage      = 1;
        this.fetchData();
    }

    // ── DEBOUNCE FOR RENT INPUTS (Step 12) ───────────────────────────
    // Debounce = wait 300ms after user stops typing before fetching.
    // This avoids firing an Apex call on every single keypress.
    _debounceTimer;

    handleMinRentChange(event) {
        this.minRent = event.target.value ? parseFloat(event.target.value) : null;
        this.debounceRefresh();
    }

    handleMaxRentChange(event) {
        this.maxRent = event.target.value ? parseFloat(event.target.value) : null;
        this.debounceRefresh();
    }

    debounceRefresh() {
        clearTimeout(this._debounceTimer);
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this._debounceTimer = setTimeout(() => {
            this.currentPage = 1;
            this.fetchData();
        }, 300);
    }

    get statusOptions() {
    return [
        { label: 'All', value: '' },
        { label: 'Available', value: 'Available' },
        { label: 'Occupied',  value: 'Occupied'  }
    ];
}

get furnishingOptions() {
    return [
        { label: 'All',             value: '' },
        { label: 'Furnished',       value: 'Furnished' },
        { label: 'Semi-Furnished',  value: 'Semi-Furnished' },
        { label: 'Unfurnished',     value: 'Unfurnished' }
    ];
}

    // ── PAGINATION HANDLERS (Step 11) ─────────────────────────────────
    handlePrevious() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.fetchData();
        }
    }

    handleNext() {
        if (this.currentPage < this.totalPages) {
            this.currentPage++;
            this.fetchData();
        }
    }
}