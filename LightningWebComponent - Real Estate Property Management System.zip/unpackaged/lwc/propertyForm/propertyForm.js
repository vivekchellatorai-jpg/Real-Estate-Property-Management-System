import { LightningElement, track } from 'lwc';
import createProperty    from '@salesforce/apex/PropertyController.createProperty';
import linkFilesToRecord from '@salesforce/apex/FileUploadController.linkFilesToRecord';

export default class PropertyForm extends LightningElement {

    // Holds the new property's field values
    @track prop = {
        Name: '', Address__c: '', City__c: '', State__c: '',
        Postal_Code__c: '', Country__c: '', Type__c: '',
        Furnishing_Status__c: '', Status__c: '', Rent__c: null,
        Description__c: ''
    };

    // Step 15 — stores uploaded file Ids
    uploadedFileIds = [];
    newRecordId     = null;
    errorMsg        = null;
    successMsg      = null;

    // Step 14 — accept only images and pdf
    get acceptedFormats() {
        return ['.jpg', '.jpeg', '.png', '.pdf'];
    }

    // This is a placeholder Id used ONLY to allow lightning-file-upload to render.
    // We will re-link files to the real record Id after creation.
    get uploadRecordId() {
        return this.newRecordId;
    }

    handleFieldChange(event) {
        const field = event.target.dataset.field;
        this.prop = { ...this.prop, [field]: event.target.value };
    }

    // Step 15 — fires when user finishes uploading files
    handleUploadFinished(event) {
        const uploadedFiles = event.detail.files;
        // Collect the ContentDocumentId of each uploaded file
        this.uploadedFileIds = uploadedFiles.map(f => f.documentId);
    }

    // Steps 16 & 17 — submit handler
    async handleSubmit() {
        this.errorMsg   = null;
        this.successMsg = null;

        // Step 17 — validate at least one image uploaded
        if (this.uploadedFileIds.length === 0) {
            this.errorMsg = 'Please upload at least one image before submitting.';
            return;
        }

        try {
            // Step 16a — create the property record first, get back its Id
            const recordId = await createProperty({ prop: this.prop });
            this.newRecordId = recordId;

            // Step 16b — now link all uploaded files to that new record
            await linkFilesToRecord({
                recordId           : recordId,
                contentDocumentIds : this.uploadedFileIds
            });

            this.successMsg = 'Property created successfully with images!';
        } catch (err) {
            this.errorMsg = err.body?.message || 'Something went wrong.';
        }
    }
}