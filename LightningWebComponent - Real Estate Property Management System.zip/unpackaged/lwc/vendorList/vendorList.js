import { LightningElement, track } from 'lwc';
import getVendors from '@salesforce/apex/VendorController.getVendors';

export default class VendorList extends LightningElement {

    // ── DATA ──────────────────────────────────────────────────────────
    @track vendors = [];
    isLoading      = false;
    error          = null;

    // ── ON PAGE LOAD ──────────────────────────────────────────────────
    connectedCallback() {
        this.loadVendors();
    }

    // ── FETCH ALL VENDORS ─────────────────────────────────────────────
    loadVendors() {
        this.isLoading = true;
        getVendors()
            .then(data => {
                this.vendors = data;
                this.error   = null;
            })
            .catch(err => {
                this.error   = err.body?.message || 'Error loading vendors';
                this.vendors = [];
            })
            .finally(() => {
                this.isLoading = false;
            });
    }

    // ── EMPTY STATE ───────────────────────────────────────────────────
    get isEmpty() {
        return this.vendors.length === 0;
    }
}