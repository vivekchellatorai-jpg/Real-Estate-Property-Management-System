import { LightningElement, track } from 'lwc';
import getTenants    from '@salesforce/apex/TenantController.getTenants';
import createTenant  from '@salesforce/apex/TenantController.createTenant';

export default class TenantList extends LightningElement {

    // ── DATA ──────────────────────────────────────────────────────────
    @track tenants = [];   // holds all tenant records for the table
    isLoading      = false;
    error          = null;

    // ── MODAL STATE ───────────────────────────────────────────────────
    // controls whether the New Tenant form modal is visible or hidden
    isModalOpen = false;

    // ── NEW TENANT FORM FIELDS ────────────────────────────────────────
    @track newTenant = {
        Name          : '',
        Phone_Number__c: '',
        Email__c      : ''
    };

    formError   = null;
    formSuccess = null;

    // ── ON PAGE LOAD ──────────────────────────────────────────────────
    connectedCallback() {
        this.loadTenants();
    }

    // ── FETCH ALL TENANTS FROM APEX ───────────────────────────────────
    loadTenants() {
        this.isLoading = true;
        getTenants()
            .then(data => {
                this.tenants = data;
                this.error   = null;
            })
            .catch(err => {
                this.error   = err.body?.message || 'Error loading tenants';
                this.tenants = [];
            })
            .finally(() => {
                this.isLoading = false;
            });
    }

    // ── MODAL OPEN / CLOSE ────────────────────────────────────────────
    handleNewTenant() {
        this.isModalOpen = true;   // opens the modal
        this.formError   = null;
        this.formSuccess = null;
        // reset form fields every time modal opens
        this.newTenant = { Name: '', Phone_Number__c: '', Email__c: '' };
    }

    handleModalClose() {
        this.isModalOpen = false;  // closes the modal
    }

    // ── FORM FIELD CHANGE HANDLER ─────────────────────────────────────
    handleFieldChange(event) {
        const field = event.target.dataset.field;
        this.newTenant = { ...this.newTenant, [field]: event.target.value };
    }
// to handle Empty state
       get isEmpty() {
    return this.tenants.length === 0;
}
    // ── SAVE NEW TENANT ───────────────────────────────────────────────
    async handleSave() {
        this.formError   = null;
        this.formSuccess = null;

        // Basic validation — Name is required
        if (!this.newTenant.Name) {
            this.formError = 'Tenant Name is required.';
            return;
        }

        try {
            // Call Apex createTenant method
            await createTenant({ t: this.newTenant });

            this.formSuccess = 'Tenant created successfully!';
            this.isModalOpen = false;

            // Refresh the tenant list so new record appears in table
            this.loadTenants();

        } catch (err) {
            this.formError = err.body?.message || 'Error creating tenant.';
        }
 
    }
}