import { LightningElement, track } from 'lwc';
import getLeases    from '@salesforce/apex/LeaseController.getLeases';
import createLease  from '@salesforce/apex/LeaseController.createLease';
import getProperties   from '@salesforce/apex/PropertyController.getProperties';
import getTenants      from '@salesforce/apex/TenantController.getTenants';

export default class LeaseList extends LightningElement {

    // ── DATA ──────────────────────────────────────────────────────────
    @track leases  = [];   // holds all lease records for the table
    isLoading      = false;
    error          = null;

    // ── MODAL STATE ───────────────────────────────────────────────────
    isModalOpen    = false;
    formError      = null;
    formSuccess    = null;

    // ── NEW LEASE FORM FIELDS ─────────────────────────────────────────
    @track newLease = {
        Property__c          : '',
        Tenant__c            : '',
        Agreed_Monthly_Rent__c: '',
        Start_Date__c        : '',
        End_Date__c          : '',
        Terms__c             : ''
    };

    // Property and Tenant lookup options
    @track propertyOptions = [];
    @track tenantOptions   = [];

    // ── ON PAGE LOAD ──────────────────────────────────────────────────
    connectedCallback() {
        this.loadLeases();
        this.loadLookupOptions();
    }

    // ── FETCH ALL LEASES ──────────────────────────────────────────────
    loadLeases() {
        this.isLoading = true;
        getLeases()
            .then(data => {
                this.leases = data;
                this.error  = null;
            })
            .catch(err => {
                this.error  = err.body?.message || 'Error loading leases';
                this.leases = [];
            })
            .finally(() => {
                this.isLoading = false;
            });
    }

    // ── LOAD PROPERTY AND TENANT OPTIONS FOR DROPDOWNS ────────────────
    loadLookupOptions() {
        // Load properties for the dropdown
        getProperties()
            .then(data => {
                this.propertyOptions = data.map(p => ({
                    label: p.Name,
                    value: p.Id
                }));
            });

        // Load tenants for the dropdown
        getTenants()
            .then(data => {
                this.tenantOptions = data.map(t => ({
                    label: t.Name,
                    value: t.Id
                }));
            });
    }

    // ── EMPTY STATE CHECK ─────────────────────────────────────────────
    get isEmpty() {
        return this.leases.length === 0;
    }

    // ── MODAL OPEN / CLOSE ────────────────────────────────────────────
    handleNewLease() {
        this.isModalOpen = true;
        this.formError   = null;
        this.formSuccess = null;
        // Reset form fields every time modal opens
        this.newLease = {
            Property__c           : '',
            Tenant__c             : '',
            Agreed_Monthly_Rent__c: '',
            Start_Date__c         : '',
            End_Date__c           : '',
            Terms__c              : ''
        };
    }

    handleModalClose() {
        this.isModalOpen = false;
    }

    // ── FORM FIELD CHANGE HANDLER ─────────────────────────────────────
    handleFieldChange(event) {
        const field = event.target.dataset.field;
        this.newLease = { ...this.newLease, [field]: event.target.value };
    }

    // ── VALIDATION ────────────────────────────────────────────────────
    validateForm() {
        if (!this.newLease.Property__c) {
            this.formError = 'Please select a Property.';
            return false;
        }
        if (!this.newLease.Tenant__c) {
            this.formError = 'Please select a Tenant.';
            return false;
        }
        if (!this.newLease.Agreed_Monthly_Rent__c) {
            this.formError = 'Please enter Agreed Monthly Rent.';
            return false;
        }
        if (!this.newLease.Start_Date__c) {
            this.formError = 'Please enter a Start Date.';
            return false;
        }
        if (!this.newLease.End_Date__c) {
            this.formError = 'Please enter an End Date.';
            return false;
        }
        if (this.newLease.Start_Date__c >= this.newLease.End_Date__c) {
            this.formError = 'End Date must be after Start Date.';
            return false;
        }
        return true;
    }

    // ── SAVE NEW LEASE ────────────────────────────────────────────────
    async handleSave() {
        this.formError   = null;
        this.formSuccess = null;

        // Run validation first
        if (!this.validateForm()) return;

        try {
            // Call Apex createLease method
            await createLease({ l: this.newLease });

            this.formSuccess = 'Lease Agreement created successfully!';
            this.isModalOpen = false;

            // Refresh the lease list so new record appears
            this.loadLeases();

        } catch (err) {
            this.formError = err.body?.message || 'Error creating lease.';
        }

        
    }
    loadLookupOptions() {
    // Load all properties for dropdown (no filters needed here)
    getProperties({
        pageSize        : 200,
        pageNumber      : 1,
        minRent         : null,
        maxRent         : null,
        status          : '',
        furnishingStatus: ''
    })
    .then(data => {
        this.propertyOptions = data.map(p => ({
            label: p.Name,
            value: p.Id
        }));
    });

    // Load all tenants for dropdown
    getTenants()
    .then(data => {
        this.tenantOptions = data.map(t => ({
            label: t.Name,
            value: t.Id
        }));
    });
}
}