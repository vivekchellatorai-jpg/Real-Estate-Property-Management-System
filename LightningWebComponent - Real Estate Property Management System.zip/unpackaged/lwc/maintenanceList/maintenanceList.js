import { LightningElement, track } from 'lwc';
import getMaintenanceRequests   from '@salesforce/apex/MaintenanceController.getMaintenanceRequests';
import createMaintenanceRequest from '@salesforce/apex/MaintenanceController.createMaintenanceRequest';
import getProperties            from '@salesforce/apex/PropertyController.getProperties';

export default class MaintenanceList extends LightningElement {

    // ── DATA ──────────────────────────────────────────────────────────
    @track requests        = [];
    @track propertyOptions = [];
    isLoading              = false;
    error                  = null;

    // ── MODAL STATE ───────────────────────────────────────────────────
    isModalOpen  = false;
    formError    = null;

    // ── FORM FIELDS ───────────────────────────────────────────────────
    @track newRequest = {
        Property__c   : '',
        Status__c     : 'Open',
        Description__c: ''
    };

    // ── STATUS OPTIONS ────────────────────────────────────────────────
    get statusOptions() {
        return [
            { label: 'Open',        value: 'Open'        },
            { label: 'In Progress', value: 'In Progress' },
            { label: 'Completed',   value: 'Completed'   },
            { label: 'Cancelled',   value: 'Cancelled'   }
        ];
    }

    // ── SAFE REQUESTS GETTER ──────────────────────────────────────────
    // This safely handles null/undefined Property__r and Vendor__r
    // so the table NEVER crashes even if relations are missing
    get safeRequests() {
        if (!this.requests || this.requests.length === 0) {
            return [];
        }
        return this.requests.map(req => {
            return {
                Id            : req.Id,
                Name          : req.Name             || 'N/A',
                PropertyName  : (req.Property__r && req.Property__r.Name)
                                ? req.Property__r.Name
                                : 'N/A',
                VendorName    : (req.Vendor__r && req.Vendor__r.Name)
                                ? req.Vendor__r.Name
                                : 'Not Assigned Yet',
                Status__c     : req.Status__c         || 'N/A',
                Description__c: req.Description__c    || 'N/A'
            };
        });
    }

    // ── EMPTY STATE ───────────────────────────────────────────────────
    get isEmpty() {
        return this.safeRequests.length === 0;
    }

    // ── ON PAGE LOAD ──────────────────────────────────────────────────
    connectedCallback() {
        this.loadRequests();
        this.loadPropertyOptions();
    }

    // ── LOAD MAINTENANCE REQUESTS ─────────────────────────────────────
    loadRequests() {
        this.isLoading = true;
        this.error     = null;
        getMaintenanceRequests()
            .then(data => {
                // Store raw data — safeRequests getter handles display
                this.requests  = data ? data : [];
            })
            .catch(err => {
                this.error    = err.body ? err.body.message : 'Error loading requests';
                this.requests = [];
            })
            .finally(() => {
                this.isLoading = false;
            });
    }

    // ── LOAD PROPERTY OPTIONS ─────────────────────────────────────────
    loadPropertyOptions() {
        getProperties({
            pageSize        : 200,
            pageNumber      : 1,
            minRent         : null,
            maxRent         : null,
            status          : '',
            furnishingStatus: ''
        })
        .then(data => {
            this.propertyOptions = data.map(p => ({
                label: p.Name,
                value: p.Id
            }));
        })
        .catch(err => {
            console.error('Error loading properties:', err);
        });
    }

    // ── MODAL HANDLERS ────────────────────────────────────────────────
    handleNewRequest() {
        this.isModalOpen = true;
        this.formError   = null;
        this.newRequest  = {
            Property__c   : '',
            Status__c     : 'Open',
            Description__c: ''
        };
    }

    handleModalClose() {
        this.isModalOpen = false;
        this.formError   = null;
    }

    // ── FIELD CHANGE ──────────────────────────────────────────────────
    handleFieldChange(event) {
        const field = event.target.dataset.field;
        this.newRequest = {
            ...this.newRequest,
            [field]: event.target.value
        };
    }

    // ── VALIDATION ────────────────────────────────────────────────────
    validateForm() {
        if (!this.newRequest.Property__c) {
            this.formError = 'Please select a Property.';
            return false;
        }
        if (!this.newRequest.Description__c) {
            this.formError = 'Please enter a Description.';
            return false;
        }
        return true;
    }

    // ── SAVE REQUEST ──────────────────────────────────────────────────
    async handleSave() {
        this.formError = null;

        if (!this.validateForm()) return;

        try {
            await createMaintenanceRequest({ req: this.newRequest });
            this.isModalOpen = false;

            // Small delay then reload so vendor shows up
            setTimeout(() => {
                this.loadRequests();
            }, 500);

        } catch (err) {
            this.formError = err.body ? err.body.message : 'Error creating request.';
        }
    }
}